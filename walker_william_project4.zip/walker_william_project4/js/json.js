//Rashad Muhammad
//Project 4
//VFW - 1201


var json = {
	"Jump1": {
		"fname": ["First Name:", "James"],
		"lname":["Last Name:", "Roberts"],
		"dateEntered": ["Date Entered:", "2012-05-02"],
		"scheduledJumpDate": ["Scheduled Jump Date:", "2012-05-05"],
		"jumpTime": ["Jump Time:", "1345"],
		"jumpday": ["Jump Day(s):", "Monday"],
		"difficulty": ["Difficulty Meter:", "2"],
		"comments": ["Comments about this jump:", "This was a great jump!"]
	},
	"Jump2": {
		"fname": ["First Name:", "Robert"],
		"lname":["Last Name:", "James"],
		"dateEntered": ["Date Entered:", "2012-05-03"],
		"scheduledJumpDate": ["Scheduled Jump Date:", "2012-05-06"],
		"jumpTime": ["Jump Time:", "1500"],
		"jumpday": ["Jump Day(s):", "Tuesday"],
		"difficulty": ["Difficulty Meter:", "7"],
		"comments": ["Comments about this jump:", "This was a awful jump!"]
	},
	"Jump3": {
		"fname": ["First Name:", "Calvin"],
		"lname":["Last Name:", "Johnson"],
		"dateEntered": ["Date Entered:", "2012-05-07"],
		"scheduledJumpDate": ["Scheduled Jump Date:", "2012-05-10"],
		"jumpTime": ["Jump Time:", "1950"],
		"jumpday": ["Jump Day(s):", "Sunday"],
		"difficulty": ["Difficulty Meter:", "5"],
		"comments": ["Comments about this jump:", "The winds were too high!"]
	}