//William L. Walker
//Project 2
// Visual Frameworks, 1209


window.addEventListener("DOMContentLoaded", function() {
	function $(x) {
		var theElement = document.getElementById(x);
		return theElement; 
	}
	
        function makeCats(){
		var formTag = document.getElementsByTagName("form");  		
			selectLi = $('select'),
			makeSelect = document.createElement('select');
			makeSelect.setAttribute("First Name", "M.I.", "Last Name", "Rank/Grade", "E-mail", "Jump Date");
		for (var i=0, j=showDropZone.length; i<j; i++){
			var makeOption = document.createElement('option');
			var optText = showDropZone[i];
			makeOption.setAttribute("value", optText);
			makeOption.innerHTML = optText;  						 
			makeSelect.appendChild(makeOption);
		}
		selectLi.appendChild(makeSelect);
               var showDropZone = [ "Corregidor", "Veghel", "Sukchon"],
		dayofweekValue = "";
	
        makeCats(); 
	}
	
	function storeData(key){
                var id= Math.floor(Math.random()*10000001);
                getSelectedRadio();
		getCeckboxValue();
		
		var item                        =[];
			item.FirstName          =("First Name", $('fname').value);
                        item.Rank               =("Rank",  $('rank').value);
                        item.lastName           =("Last Name", $('lname').value);
                        item.scheduledJumpDate  =("Scheduled Jump Date", $('scheduledJumpDate').value);
                        item.dropZoneName       =("Name of Drop Zone", $('DropZonename').value);
			item.jumpDate           =("Jump Date", $('jumpdate').value);
			item.difficultyMeter    =("Difficulty Meter. On a Scale of 1 to 5 with 1 being the least, I rate the jump as".value);
			item.comments           =("Comments about this jump", $('comments').value);
                    localStorage.setItem(id, JSON.stringify(item));
                    alert("Jump Data Saved!");
                    
                    function getCheckboxValue(){
		var checkbx = document.forms[0].jumpday;
		for (var i=0; i<checkbx.length; i++){
			if (checkbx[i].checked){
				dayofweekValue += checkbx[i].value + "\n";				
			}
		}
	}
	function toggleControls(t){
		switch(t){
			case "on":
				$('showsForm').style.display = "none";
				$('clear').style.display = "inline";
				$('displayData').style.display = "none";
				$('addNew').style.display = "inline";
				break;
			case "off":
				$('showsForm').style.display = "block";
				$('clear').style.display = "inline";
				$('displayData').style.display = "inline";
				$('addNew').style.display = "none";
				$('items').style.display = "none";
				break;
			default:
				return false;
		}
	}
	f
	}
		function getData() {
			toggleControls("on");
			if (localStorage.length === 0){
				alert("You have no logs saved.");
			}
			var makeDiv = document.createElement('div');
			makeDiv.setAttribute("id", "items");
			var makeList = document.createElement('ul');
			makeDiv.appendChild(makeList);
			document.body.appendChild(makeDiv);
			$('items').style.display = "block";
			for (var i=0, j=localStorage.length; i<j; i++){
				var makeli= document.createElement('li');
				makeList.appendChild(makeli);
				var key = localStorage.key(i);
				var value = localStorage.getItem(key); 
				var obj = JSON.parse(value);
				var makeSubList = document.createElement('ul');
				makeli.appendChild(makeSubList);
				for (var t in obj){
					var makeSubli = document.createElement('li');
					makeSubList.appendChild(makeSubli);
					var optsubText = obj[t][0]+" "+ obj[t][1];
					makeSubli.innerHTML = optsubText;
				}
			}
		}
		function clearLocal(){
			if (localStorage.length === 0){
				alert("No data in storage.");
			}
			else{
				localStorage.clear();
				alert("All shows are deleted!");
				window.location.reload();
				return false;
			}
		}
	var displayData = $('displayData');
	displayData.addEventListener("click", getData);
	var clearData = $('clear');
	clearData.addEventListener("click", clearLocal);
	var save = $('submit');
	save.addEventListener("click", storeData);
});


